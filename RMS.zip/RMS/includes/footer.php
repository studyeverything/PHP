<footer id="footer" class="midnight-blue">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          &copy; 2018. All Rights Reserved.
          <div class="credits">
           
            <a href="#">Student Name</a> by <a href="#">Student Number</a>
          </div>
        </div>
        <div class="col-sm-6">
          <ul class="pull-right">
            <li><a href="#"><i class="fab fa-html5 fa-3x"></i></a></li>
            <li><a href="#"><i class="fab fa-js fa-3x"></i></a></li>
            <li><a href="#"><i class="fab fa-php fa-3x "></i></a></li>
            <li><a href="#"><i class="fab fa-css3 fa-3x"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

        <!-- jQuery  -->
<script src="plugins/jquery/jquery.min.js"></script>
         <!-- Bootstrap Js  -->
<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
         <!-- fontawesome Js  -->
<script defer src="plugins/font-awesome/svg-with-js/js/fontawesome-all.js"></script>
          <!-- Our datatable js -->
 <script type="text/javascript" src="plugins/DataTables/datatables.min.js"></script>
          <!-- Our Custom js -->
 <script src="assets/js/main.js"></script>

</body>
</html>
