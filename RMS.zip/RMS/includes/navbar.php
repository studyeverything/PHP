<nav class="navbar navbar-default">
                    <div class="container-fluid">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span>Toggle Sidebar</span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right">
                                <li class="<?php echo ($_SERVER['PHP_SELF'] == '/rms/viewdocs.php' ? ' active' : '');?>"><a href="viewdocs.php">Documents</a></li>
                                <li class="<?php echo ($_SERVER['PHP_SELF'] == '/rms/viewusers.php' ? ' active' : '');?>"><a href="viewusers.php">Users</a></li>
                                <li><a href="#">Help</a></li>
                                <li><a href="scripts/logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>                 





